import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;

public class ContadorPalabras {

    public static void main(String[] args) {
        String archivo = "divina_comedia_sp.txt";  // Reemplaza con la ruta de tu archivo
        Map<Integer, Integer> contadorPorLongitud = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] palabras = linea.split("\\s+");
                for (String palabra : palabras) {
                    palabra = normalizar(palabra);  // Normalizamos para manejar acentos
                    int longitud = palabra.length();
                    if (longitud >= 2 && longitud <= 10) {
                        contadorPorLongitud.put(longitud, contadorPorLongitud.getOrDefault(longitud, 0) + 1);
                    }
                }
            }

            // Imprimir resultados
            for (Map.Entry<Integer, Integer> entry : contadorPorLongitud.entrySet()) {
                int longitud = entry.getKey();
                int cantidad = entry.getValue();
                System.out.println("Palabras de " + longitud + " letras: " + cantidad);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Función para normalizar la cadena eliminando acentos
    public static String normalizar(String input) {
        return Normalizer.normalize(input, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}
